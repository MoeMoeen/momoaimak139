"""
Store Data Analyzer
Reads daily sales data from a text file and generates an analytical report.
"""

import os

def read_sales_data(filename):
    """
    Reads sales data from file and returns parsed data.
    Returns list of tuples: (product_name, price, quantity)
    """
    sales_data = []
    
    # Check if file exists
    if not os.path.exists(filename):
        print(f"File {filename} not found. Creating empty file.")
        with open(filename, 'w') as file:
            pass
        return sales_data
    
    with open(filename, 'r') as file:
        for line in file:
            line = line.strip()
            if line:  # Skip empty lines
                try:
                    parts = [part.strip() for part in line.split(',')]
                    if len(parts) == 3:
                        product_name = parts[0]
                        price = float(parts[1])
                        quantity = int(parts[2])
                        sales_data.append((product_name, price, quantity))
                except (ValueError, IndexError):
                    # Skip invalid lines silently as per requirements
                    continue
    
    return sales_data

def calculate_report(sales_data):
    """
    Calculates and returns report data based on sales data.
    """
    if not sales_data:
        return {
            'num_transactions': 0,
            'total_sales': 0.0,
            'best_selling_product': None,
            'best_selling_quantity': 0,
            'average_purchase': 0.0
        }
    
    total_sales = 0.0
    product_quantities = {}
    transaction_amounts = []
    
    # Process each transaction
    for product_name, price, quantity in sales_data:
        # Calculate transaction amount
        transaction_amount = price * quantity
        total_sales += transaction_amount
        transaction_amounts.append(transaction_amount)
        
        # Track product quantities
        if product_name in product_quantities:
            product_quantities[product_name] += quantity
        else:
            product_quantities[product_name] = quantity
    
    # Find best-selling product
    best_selling_product = None
    best_selling_quantity = 0
    if product_quantities:
        best_selling_product = max(product_quantities.keys(), key=lambda x: product_quantities[x])
        best_selling_quantity = product_quantities[best_selling_product]
    
    # Calculate average purchase amount
    average_purchase = total_sales / len(sales_data) if sales_data else 0.0
    
    return {
        'num_transactions': len(sales_data),
        'total_sales': total_sales,
        'best_selling_product': best_selling_product,
        'best_selling_quantity': best_selling_quantity,
        'average_purchase': average_purchase
    }

def display_report(report_data):
    """
    Displays the sales report in the specified format.
    """
    print("--- Daily Sales Report ---")
    print(f"Number of transactions: {report_data['num_transactions']}")
    print(f"Total sales: ${report_data['total_sales']:.2f}")
    
    if report_data['best_selling_product']:
        print(f"Best-selling product: {report_data['best_selling_product']} ({report_data['best_selling_quantity']} units sold)")
    else:
        print("Best-selling product: No data available")
    
    print(f"Average purchase amount: ${report_data['average_purchase']:.2f}")

def add_new_sale(filename):
    """
    Allows user to add a new sale to the file.
    """
    try:
        product_name = input("Enter product name: ").strip()
        price = float(input("Enter price: "))
        quantity = int(input("Enter quantity: "))
        
        # Validate inputs
        if not product_name:
            print("Product name cannot be empty.")
            return
        
        if price <= 0 or quantity <= 0:
            print("Price and quantity must be positive numbers.")
            return
        
        # Append to file
        with open(filename, 'a') as file:
            file.write(f"{product_name}, {price}, {quantity}\n")
        
        print("Sale added successfully!")
        
    except ValueError:
        print("Invalid input. Please enter valid numbers for price and quantity.")
    except Exception as e:
        print(f"Error adding sale: {e}")

def main():
    """
    Main program loop.
    """
    # Use relative path to sales.txt file
    sales_file = "../../sales.txt"
    
    while True:
        print("\n" + "="*40)
        print("Store Data Analyzer")
        print("="*40)
        print("1. View the report")
        print("2. Add a new sale")
        print("3. Exit")
        
        choice = input("\nEnter your choice (1-3): ").strip()
        
        if choice == '1':
            # Read sales data and generate report
            sales_data = read_sales_data(sales_file)
            report_data = calculate_report(sales_data)
            display_report(report_data)
            
        elif choice == '2':
            # Add new sale
            add_new_sale(sales_file)
            
        elif choice == '3':
            print("Thank you for using Store Data Analyzer!")
            break
            
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    main()
