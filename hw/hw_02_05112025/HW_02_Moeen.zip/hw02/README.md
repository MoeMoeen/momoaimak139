**Question 1**


**Digital Notebook**

Write a program that works like a simple notebook and can **save, edit, and display notes** using a file.

**Requirements:**

When the program runs, it should print the following menu:

1. Add a new note
2. View all notes
3. Search notes
4. Delete a specific note
5. Exit

Each note must include a **title**, **date**, and **content**.
All data should be stored in a file named **"notes.json"**.

If the file does not exist, the program should **create it**.
When a new note is added, it should be **appended** to the list in the JSON file.

The **search** option should display all notes whose **titles contain** the user-entered text.

In the **delete** option, only the note with the specified **title** should be removed.

After each operation, the program should show the **main menu again** so that the user can continue.

Use a **while loop** for continuous execution of the program and use **`json.dump()` / `json.load()`** to manage the file.


**Question 2**

**Store Data Analyzer**

Write a program that reads the **daily sales data** of a store from a text file and then generates an **analytical report**.

**Description:**

A text file named **"sales.txt"** (provided with this exercise) contains multiple lines, each representing a **sales transaction** in the following format:

```
product_name, price, quantity
```

**Example:**

```
milk, 2.5, 3
bread, 1.8, 5
cheese, 4.2, 2
milk, 2.5, 1
```

The program should read the file and calculate the following:

* **Total daily sales** based on `price * quantity`
* **Total number of transactions**
* **Best-selling product** (based on total quantity sold)
* **Average purchase amount**

---

**The output should be printed in the following format:**

```
--- Daily Sales Report ---
Number of transactions: 12  
Total sales: $148.70  
Best-selling product: milk (15 units sold)  
Average purchase amount: $12.39
```

---

Then, the user should be able to choose:

1. View the report
2. Add a new sale (which should be saved in the file)
3. Exit

The data must be **saved in the same file** and be **readable in future executions**.

If the file contains an **incomplete or invalid line**, it should be **skipped using try-except** without printing any error messages.
