import json
import os
from datetime import datetime


def load_notes():
    """Load notes from the JSON file. Create file if it doesn't exist."""
    if not os.path.exists("notes.json"):
        return []
    
    try:
        with open("notes.json", "r") as file:
            return json.load(file)
    except (json.JSONDecodeError, FileNotFoundError):
        return []


def save_notes(notes):
    """Save notes to the JSON file."""
    with open("notes.json", "w") as file:
        json.dump(notes, file, indent=2)


def add_note():
    """Add a new note to the collection."""
    title = input("Enter note title: ").strip()
    if not title:
        print("Title cannot be empty!")
        return
    
    content = input("Enter note content: ").strip()
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    note = {
        "title": title,
        "date": date,
        "content": content
    }
    
    notes = load_notes()
    notes.append(note)
    save_notes(notes)
    print(f"Note '{title}' added successfully!")


def view_all_notes():
    """Display all notes."""
    notes = load_notes()
    
    if not notes:
        print("No notes found.")
        return
    
    print("\n--- All Notes ---")
    for i, note in enumerate(notes, 1):
        print(f"\n{i}. Title: {note['title']}")
        print(f"   Date: {note['date']}")
        print(f"   Content: {note['content']}")


def search_notes():
    """Search notes by title."""
    search_term = input("Enter search term for title: ").strip().lower()
    
    if not search_term:
        print("Search term cannot be empty!")
        return
    
    notes = load_notes()
    found_notes = [note for note in notes if search_term in note['title'].lower()]
    
    if not found_notes:
        print("No notes found matching your search.")
        return
    
    print(f"\n--- Search Results for '{search_term}' ---")
    for i, note in enumerate(found_notes, 1):
        print(f"\n{i}. Title: {note['title']}")
        print(f"   Date: {note['date']}")
        print(f"   Content: {note['content']}")


def delete_note():
    """Delete a specific note by title."""
    title = input("Enter the exact title of the note to delete: ").strip()
    
    if not title:
        print("Title cannot be empty!")
        return
    
    notes = load_notes()
    original_count = len(notes)
    
    # Filter out notes with matching title
    notes = [note for note in notes if note['title'] != title]
    
    if len(notes) == original_count:
        print(f"No note found with title '{title}'")
        return
    
    save_notes(notes)
    print(f"Note '{title}' deleted successfully!")


def display_menu():
    """Display the main menu."""
    print("\n" + "="*30)
    print("      Digital Notebook")
    print("="*30)
    print("1. Add a new note")
    print("2. View all notes")
    print("3. Search notes")
    print("4. Delete a specific note")
    print("5. Exit")
    print("-"*30)


def main():
    """Main program loop."""
    print("Welcome to Digital Notebook!")
    
    while True:
        display_menu()
        
        try:
            choice = input("Please select an option (1-5): ").strip()
            
            if choice == "1":
                add_note()
            elif choice == "2":
                view_all_notes()
            elif choice == "3":
                search_notes()
            elif choice == "4":
                delete_note()
            elif choice == "5":
                print("Thank you for using Digital Notebook. Goodbye!")
                break
            else:
                print("Invalid option. Please select 1-5.")
        
        except KeyboardInterrupt:
            print("\n\nProgram interrupted. Goodbye!")
            break
        except Exception as e:
            print(f"An error occurred: {e}")


if __name__ == "__main__":
    main()
