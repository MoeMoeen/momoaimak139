def main():
    print("Hello from hw01!")


if __name__ == "__main__":
    main()
