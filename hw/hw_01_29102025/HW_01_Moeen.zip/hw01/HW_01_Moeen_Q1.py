def get_number(prompt):
    """دریافت عدد از کاربر با بررسی صحت ورودی"""
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("لطفا یک عدد معتبر وارد کنید.")

def get_operation():
    """دریافت نوع عملیات از کاربر"""
    operations = {
        '1': ('جمع', '+'),
        '2': ('تفریق', '-'),
        '3': ('ضرب', '*'),
        '4': ('تقسیم', '/')
    }
    
    while True:
        print("\nعملیات مورد نظر را انتخاب کنید:")
        for key, (name, symbol) in operations.items():
            print(f"{key}. {name} ({symbol})")
        
        choice = input("انتخاب شما (1-4): ")
        if choice in operations:
            return choice, operations[choice][1]
        else:
            print("انتخاب نامعتبر! لطفا عددی بین 1 تا 4 وارد کنید.")

def perform_calculation(num1, num2, operation):
    """انجام محاسبه بر اساس عملیات انتخاب شده"""
    if operation == '+':
        return num1 + num2
    elif operation == '-':
        return num1 - num2
    elif operation == '*':
        return num1 * num2
    elif operation == '/':
        return num1 / num2

def handle_division(num1):
    """مدیریت عملیات تقسیم با بررسی تقسیم بر صفر"""
    while True:
        num2 = get_number("عدد دوم (مخرج) را وارد کنید: ")
        
        if num2 == 0:
            print("خطا: تقسیم بر صفر ممکن نیست!")
            print(f"عدد اول (صورت) همچنان {num1} باقی می‌ماند.")
            print("لطفا مقدار مخرج را تغییر دهید.")
            continue
        else:
            return num2

def calculator():
    """ماشین حساب اصلی"""
    print("=" * 50)
    print("        ماشین حساب ساده")
    print("=" * 50)
    
    while True:
        try:
            # دریافت عدد اول
            num1 = get_number("عدد اول را وارد کنید: ")
            
            # دریافت نوع عملیات
            choice, operation = get_operation()
            
            # دریافت عدد دوم (با مدیریت خاص برای تقسیم)
            if operation == '/':
                num2 = handle_division(num1)
            else:
                num2 = get_number("عدد دوم را وارد کنید: ")
            
            # انجام محاسبه
            result = perform_calculation(num1, num2, operation)
            
            # نمایش نتیجه
            print(f"\nنتیجه: {num1} {operation} {num2} = {result}")
            
            # پرسش برای ادامه
            print("\nآیا می‌خواهید محاسبه دیگری انجام دهید؟")
            continue_calc = input("برای ادامه 'y' و برای خروج 'n' وارد کنید: ").lower()
            
            if continue_calc != 'y':
                print("از استفاده شما متشکریم!")
                break
                
        except KeyboardInterrupt:
            print("\n\nبرنامه متوقف شد.")
            break
        except Exception as e:
            print(f"خطای غیرمنتظره: {e}")
            print("لطفا دوباره تلاش کنید.")

if __name__ == "__main__":
    calculator()