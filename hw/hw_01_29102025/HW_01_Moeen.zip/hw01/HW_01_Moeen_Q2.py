import random

def number_guessing_game():
    """
    Number Guessing Game
    The program generates a random number between 1-100 and the user tries to guess it.
    The program provides feedback: 'low' if guess is smaller, 'large' if guess is bigger.
    """
    # Generate random number between 1 and 100
    TrueValue = random.randint(1, 100)
    print('The random number is: ', TrueValue)
    print("=" * 50)
    print("Welcome to the Number Guessing Game!")
    print("I have selected a number between 1 and 100.")
    print("Try to guess it! I'll tell you if your guess is too low or too high.")
    print("=" * 50)
    
    attempts = 0
    
    while True:
        try:
            # Get user input
            guess = int(input("\nEnter your guess (1-100): "))
            attempts += 1
            
            # Validate input range
            if guess < 1 or guess > 100:
                print("Please enter a number between 1 and 100.")
                attempts -= 1  # Don't count invalid attempts
                continue
            
            # Check the guess
            if guess < TrueValue:
                print("low")
                print("Your guess is too small! Try a larger number.")
            elif guess > TrueValue:
                print("large")
                print("Your guess is too big! Try a smaller number.")
            else:
                print(f"🎉 Congratulations! You found the number {TrueValue}!")
                print(f"It took you {attempts} attempts.")
                break
                
        except ValueError:
            print("Invalid input! Please enter a valid number.")
            attempts -= 1  # Don't count invalid attempts

def optimal_strategy_demo():
    """
    Demonstrates the optimal binary search strategy for guessing numbers
    """
    print("\n" + "=" * 60)
    print("OPTIMAL STRATEGY DEMONSTRATION - Binary Search")
    print("=" * 60)
    print("The most efficient way to guess a number between 1-100 is using Binary Search.")
    print("This strategy guarantees finding any number in at most 7 attempts!")
    print("\nHow it works:")
    print("1. Start with the middle number (50)")
    print("2. If too high, search the lower half (1-49)")
    print("3. If too low, search the upper half (51-100)")
    print("4. Repeat by always choosing the middle of the remaining range")
    
    # Generate a new random number for demonstration
    TrueValue = random.randint(1, 100)
    print(f"\nLet's demonstrate with TrueValue = {TrueValue}")
    
    low = 1
    high = 100
    attempts = 0
    
    while low <= high:
        attempts += 1
        guess = (low + high) // 2
        print(f"\nAttempt {attempts}: Guessing {guess} (range: {low}-{high})")
        
        if guess < TrueValue:
            print("Result: low (guess is smaller than TrueValue)")
            low = guess + 1
        elif guess > TrueValue:
            print("Result: large (guess is bigger than TrueValue)")
            high = guess - 1
        else:
            print(f"Found it! TrueValue = {TrueValue} in {attempts} attempts")
            break
    
    print(f"\nBinary search found the answer in {attempts} attempts!")
    print("This is guaranteed to be optimal - no strategy can do better in the worst case.")

def compare_strategies():
    """
    Compares different guessing strategies by running multiple simulations
    """
    print("\n" + "=" * 60)
    print("STRATEGY COMPARISON")
    print("=" * 60)
    
    def linear_search(target):
        """Linear search from 1 to 100"""
        for i in range(1, 101):
            if i == target:
                return i
        return 100
    
    def random_search(target):
        """Random guessing strategy"""
        guessed = set()
        attempts = 0
        while True:
            attempts += 1
            guess = random.randint(1, 100)
            if guess in guessed:
                continue
            guessed.add(guess)
            if guess == target:
                return attempts
    
    def binary_search(target):
        """Binary search strategy"""
        low, high = 1, 100
        attempts = 0
        while low <= high:
            attempts += 1
            guess = (low + high) // 2
            if guess < target:
                low = guess + 1
            elif guess > target:
                high = guess - 1
            else:
                return attempts
        return attempts
    
    # Run simulations
    num_simulations = 100
    linear_total = 0
    random_total = 0
    binary_total = 0
    
    print(f"Running {num_simulations} simulations...")
    
    for _ in range(num_simulations):
        target = random.randint(1, 100)
        linear_total += linear_search(target)
        random_total += random_search(target)
        binary_total += binary_search(target)
    
    print(f"\nResults (average attempts over {num_simulations} games):")
    print(f"Linear Search (1,2,3...): {linear_total/num_simulations:.2f} attempts")
    print(f"Random Search: {random_total/num_simulations:.2f} attempts")
    print(f"Binary Search: {binary_total/num_simulations:.2f} attempts")
    print("\nBinary search is clearly the most efficient strategy!")

def main():
    """
    Main function to run the number guessing game and demonstrations
    """
    while True:
        print("\n" + "=" * 60)
        print("NUMBER GUESSING GAME - MENU")
        print("=" * 60)
        print("1. Play the guessing game")
        print("2. See optimal strategy demonstration")
        print("3. Compare different strategies")
        print("4. Exit")
        
        choice = input("\nEnter your choice (1-4): ")
        
        if choice == '1':
            number_guessing_game()
        elif choice == '2':
            optimal_strategy_demo()
        elif choice == '3':
            compare_strategies()
        elif choice == '4':
            print("Thanks for playing! Goodbye!")
            break
        else:
            print("Invalid choice! Please enter 1, 2, 3, or 4.")

if __name__ == "__main__":
    main()